package com.event.contoller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.event.model.Assignment;
import com.event.model.Schedule;
import com.event.model.Trainee;
import com.event.model.Trainee1;
import com.event.model.TraineeImage;
import com.event.repository.AssignmentRepository;
import com.event.repository.ScheduleRepository;
import com.event.repository.TraineeImageRepository;
import com.event.repository.TraineeRepository;
import com.event.repository.TraineesRepository;
import com.event.utility.MailUtility;



@RestController
@RequestMapping("/api/v2")
public class EventController {
	@Autowired
	private TraineeImageRepository traineeImageRepository;
	@Autowired
	private TraineeRepository traineeRepository;
	@Autowired
	private TraineesRepository traineesRepository;
	@Autowired
	private AssignmentRepository assignmentRepository;
	@Autowired
	private ScheduleRepository scheduleRepository;
	
	@Autowired
	private MailUtility mailUtility;
	
	@GetMapping("/trainees")
	public List<Trainee> getAllEmployees() {
		return traineeRepository.findAll();
	}

	/*
	 * @GetMapping("/trainees/{id}") public ResponseEntity<Employee>
	 * getEmployeeById(@PathVariable(value = "id") Long employeeId) throws
	 * ResourceNotFoundException { Employee employee =
	 * traineeRepository.findById(employeeId) .orElseThrow(() -> new
	 * ResourceNotFoundException("Employee not found for this id :: " +
	 * employeeId)); return ResponseEntity.ok().body(employee); }
	 */

	@PostMapping("/trainees") 
	public Trainee createEmployee(@Valid @RequestBody Trainee trainee) {
		return traineeRepository.save(trainee);
	}
	
	@PostMapping("/assignmentbyid")
	public Trainee schedule1(@Valid @RequestBody Trainee trainee) {
		return traineeRepository.save(trainee);
	}
	
	@PostMapping("/uploadimage")
	public TraineeImage uploadImage(@Valid @RequestBody TraineeImage traineeImage) {
		return traineeImageRepository.save(traineeImage);
	}
	
	@PostMapping("/readimage")
	public TraineeImage readimage(@Valid @RequestBody TraineeImage traineeImage) {
		return traineeImageRepository.findByUserId(traineeImage.getUserId());
	}
	
	
	@PostMapping("/sendemail")
	public Object sendEmail(@Valid @RequestBody Trainee trainee) {
		HashMap<String,String> emailResp= new HashMap<>();
		if( null!=traineeRepository.findByUserId(trainee.getUserId())){
			String Otp=getRandomNumberString();
			if (mailUtility.sendEmail("Test Email", "OTP:"+Otp, "jayaraj_2203@yahoo.com")=="success"){
				emailResp.put("success", "true");
				emailResp.put("OTP", Otp);
				return emailResp;
			}else{
				emailResp.put("success", "false");
				emailResp.put("errorMessage", "Issue with Sending Email");
				return emailResp;
			}
		}
		else{
			emailResp.put("success", "false");
			emailResp.put("errorMessage", "Email Id Not found");
			return emailResp;
		}
	}
	
	@PostMapping("/updatepassword")
	public Object updatePassword(@Valid @RequestBody Trainee trainee) {
		 Trainee tm = traineeRepository.findByUserId(trainee.getUserId());
		 if(null!=tm){
		 tm.setUserPassword(trainee.getUserPassword());
		 return traineeRepository.save(tm);
		 }
		 else 
			 return "user id not Found";
	}
	
	@GetMapping("/getschedule")
	public Optional<Schedule> schedule() {
		return scheduleRepository.findById((long) 1);
	}
	
	@PostMapping("/createschedule")
	public Schedule createSchedule(@Valid @RequestBody Schedule schedule) {
		return scheduleRepository.save(schedule);
	}
	
	@SuppressWarnings("unchecked")
	@GetMapping("/getschedulebydate")
	public List<Schedule> scheduleByDate(@RequestParam  String date) throws ParseException {
		Date startDate= new SimpleDateFormat("yyyy-MM-dd").parse(date);
		return (List<Schedule>) scheduleRepository.findByStartDateOrderByScheduleIdDesc(startDate);
	}
	
	
	@PostMapping("/trainee/login")
	public Trainee loginTrainee(@Valid @RequestBody Trainee trainee) {
		return traineeRepository.findByuserIdAndUserPassword(trainee.getUserId(), trainee.getUserPassword());
	}
	
	@PostMapping("/traineeimg/login")
	public Trainee1 loginTraineeimg(@Valid @RequestBody Trainee1 trainee) {
		return traineesRepository.findByUserIdAndUserPassword(trainee.getUserId(), trainee.getUserPassword());
	}
	
	@PostMapping("/traineesimg")
	public Trainee1 createTrainee(@Valid @RequestBody Trainee1 trainee) {
		return traineesRepository.save(trainee);
	}
	
	@PostMapping("/createassignment")
	public Assignment create(@Valid @RequestBody Assignment assignment) {

		
		return assignmentRepository.save(assignment);
	}
	
	
	/*
	 * @PutMapping("/employees/{id}") public ResponseEntity<Employee>
	 * updateEmployee(@PathVariable(value = "id") Long employeeId,
	 * 
	 * @Valid @RequestBody Employee employeeDetails) throws
	 * ResourceNotFoundException { Employee employee =
	 * employeeRepository.findById(employeeId) .orElseThrow(() -> new
	 * ResourceNotFoundException("Employee not found for this id :: " +
	 * employeeId));
	 * 
	 * employee.setEmailId(employeeDetails.getEmailId());
	 * employee.setLastName(employeeDetails.getLastName());
	 * employee.setFirstName(employeeDetails.getFirstName()); final Employee
	 * updatedEmployee = employeeRepository.save(employee); return
	 * ResponseEntity.ok(updatedEmployee); }
	 * 
	 * @DeleteMapping("/employees/{id}") public Map<String, Boolean>
	 * deleteEmployee(@PathVariable(value = "id") Long employeeId) throws
	 * ResourceNotFoundException { Employee employee =
	 * employeeRepository.findById(employeeId) .orElseThrow(() -> new
	 * ResourceNotFoundException("Employee not found for this id :: " +
	 * employeeId));
	 * 
	 * employeeRepository.delete(employee); Map<String, Boolean> response = new
	 * HashMap<>();
	 * 
	 * response.put("deleted", Boolean.TRUE); return response; }
	 */
	public  String getRandomNumberString() {
	    // It will generate 6 digit random Number.
	    // from 0 to 999999
	    Random rnd = new Random();
	    int number = rnd.nextInt(999999);

	    // this will convert any number sequence into 6 character.
	    return String.format("%06d", number);
	}
}