package com.event.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.event.model.Trainee1;

@Repository
public interface TraineesRepository extends JpaRepository<Trainee1, Long>{
	   Trainee1 findByUserIdAndUserPassword(String userId, String userPassword);
	}
