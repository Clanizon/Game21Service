package com.event.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.event.model.Trainee;

@Repository
public interface TraineeRepository extends JpaRepository<Trainee, Long>{
	  
	   Trainee findByuserIdAndUserPassword(String userId, String userPassword);
	   Trainee findByUserId(String userId);
	   
	  
	}
