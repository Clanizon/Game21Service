package com.event.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
@Entity
@Table(name = "TRAINEE_IMAGE")
public class TraineeImage {
	
	public TraineeImage() {
		super();
	}
	
	@Id
	@Column(name = "user_id", updatable = false, nullable = false)
	String userId;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	@Lob
    private String aavatarImg;

	public String getAavatarImg() {
		return aavatarImg;		       
	}

	public void setAavatarImg(String aavatarImg) {
		this.aavatarImg = aavatarImg;
	}
}
