package com.event.model;


import java.util.Date;
import java.util.Set;

import javax.persistence.*;
@Entity
@Table(name = "Schedule")
public class Schedule {
	
	public Schedule() {
		super();
	}
	

	
	
	public int getScheduleId() {
		return scheduleId;
	}

	public void setScheduleId(int scheduleId) {
		this.scheduleId = scheduleId;
	}

	public String getScheduleName() {
		return scheduleName;
	}

	public void setScheduleName(String scheduleName) {
		this.scheduleName = scheduleName;
	}



	public String getScheduleLocation() {
		return scheduleLocation;
	}

	public void setScheduleLocation(String scheduleLocation) {
		this.scheduleLocation = scheduleLocation;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getScheduleDesc() {
		return scheduleDesc;
	}

	public void setScheduleDesc(String scheduleDesc) {
		this.scheduleDesc = scheduleDesc;
	}

	public String getQrCode() {
		return qrCode;
	}

	public void setQrCode(String qrCode) {
		this.qrCode = qrCode;
	}

	public String getStartAt() {
		return startAt;
	}

	public void setStartAt(String startAt) {
		this.startAt = startAt;
	}

	public String getEndAt() {
		return endAt;
	}

	public void setEndAt(String endAt) {
		this.endAt = endAt;
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "schedule_id", updatable = false, nullable = false)
	int  scheduleId;  
	String scheduleName;
	//@JoinColumn(name = "module_id")
	
	String scheduleLocation;	
	String scheduleDesc;
	String qrCode;
	String startAt;
	
	String endAt;
	@Temporal(TemporalType.DATE)
	Date  startDate;	
	String endDate;
	
	
	@OneToMany(cascade = CascadeType.ALL,targetEntity = ScheduleContent.class)
	@JoinColumn(name = "schedule_id",referencedColumnName="schedule_id")
	private Set<ScheduleContent> scheduleContent;
	
	public Set<ScheduleContent> getScheduleContent() {
		return scheduleContent;
	}
	public void setScheduleContent(Set<ScheduleContent> scheduleContent) {
		this.scheduleContent = scheduleContent;
	}

	@OneToMany(cascade = CascadeType.ALL,targetEntity = ScheduleSpeaker.class)
	@JoinColumn(name = "schedule_id",referencedColumnName="schedule_id")
	private Set<ScheduleSpeaker> scheduleSpeaker;
	
	public Set<ScheduleSpeaker> getScheduleSpeaker() {
		return scheduleSpeaker;
	}
	public void setScheduleSpeaker(Set<ScheduleSpeaker> scheduleSpeaker) {
		this.scheduleSpeaker = scheduleSpeaker;
	}

	@OneToMany
	@JoinColumn(name = "schedule_id")
	private Set<Assignment> Assignee;
	public Set<Assignment> getAssignee() {
		return Assignee;
	}
    public void setAssignee(Set<Assignment> assignee) {
		Assignee = assignee;
	}
}
