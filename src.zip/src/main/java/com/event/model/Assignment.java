package com.event.model;

import javax.persistence.*;
@Entity
@Table(name = "Assignment")
public class Assignment {
	
	public Assignment() {
		super();
	}
	

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", updatable = false, nullable = false)
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Long getScheduleId() {
		return scheduleId;
	}
	public void setScheduleId(Long scheduleId) {
		this.scheduleId = scheduleId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public Trainee getAssignee() {
		return assignee;
	}
	public void setAssignee(Trainee assignee) {
		this.assignee = assignee;
	}
  
	


    




	

	


	@Column(name="schedule_id")
	Long scheduleId;
	String status;
	@Column(name="user_feedback")
	String userFeedback;
	
	public String getUserFeedback() {
		return userFeedback;
	}
	public void setUserFeedback(String userFeedback) {
		this.userFeedback = userFeedback;
	}
	public Long getUserRating() {
		return userRating;
	}
	public void setUserRating(Long userRating) {
		this.userRating = userRating;
	}



	@Column(name="user_rating")
	Long userRating;
	
	String createdDate;	
	@OneToOne(cascade = CascadeType.DETACH)
	@JoinColumn(name = "user_id")
	private Trainee assignee;
	
	
	/*@ManyToOne
	   private Trainee department;*/



}
