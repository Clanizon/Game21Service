package com.event.model;

import java.util.Set;

import javax.persistence.*;
@Entity
@Table(name = "trainee")
public class Trainee {
	
	public Trainee() {
		super();
	}
	
	

	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getRegisteredDate() {
		return registeredDate;
	}
	public void setRegisteredDate(String registeredDate) {
		this.registeredDate = registeredDate;
	}
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	public String getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	
	@Id
	@Column(name = "user_id", nullable = false)
	String userId;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	String mobile;
	String userPassword;
	String designation;
	String company;
	String registeredDate;
	String  experience;
	String updatedDate;
	String isActive;
	String userName;
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	@Lob
    private String aavatarImg;

	public String getAavatarImg() {
		return aavatarImg;		       
	}

	public void setAavatarImg(String aavatarImg) {
		this.aavatarImg = aavatarImg;
	}
	



}
