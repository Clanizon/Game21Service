package com.event.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "schedule_content")
public class ScheduleContent {
	
	public ScheduleContent() {
		super();
	}
	
     
	
	public long getContentScheduleId() {
		return contentScheduleId;
	}
	public void setContentScheduleId(long contentScheduleId) {
		this.contentScheduleId = contentScheduleId;
	}

	public String getContentName() {
		return contentName;
	}
	public void setContentName(String contentName) {
		this.contentName = contentName;
	}
	public String getContentDescription() {
		return contentDescription;
	}
	public void setContentDescription(String contentDescription) {
		this.contentDescription = contentDescription;
	}



	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "content_schedule_id", updatable = false, nullable = false)
	long contentScheduleId;	
	
	String contentName;
	String contentDescription;	
	
	
	
	



}
