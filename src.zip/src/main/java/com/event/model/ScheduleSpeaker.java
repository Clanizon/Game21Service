package com.event.model;

import java.util.Set;

import javax.persistence.*;
@Entity
@Table(name = "schedule_speaker")
public class ScheduleSpeaker {
	
	public ScheduleSpeaker() {
		super();
	}
	
	

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", updatable = false, nullable = false)
	long id;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	   
	@OneToOne(cascade = CascadeType.DETACH)
	@JoinColumn(name = "user_id")
	private Trainee speaker;
	public Trainee getSpeaker() {
		return speaker;
	}
	public void setSpeaker(Trainee speaker) {
		this.speaker = speaker;
	}
		
	
	
	
	



}
